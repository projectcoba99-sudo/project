# Dashboard Manajemen Mesin Produksi

Aplikasi web untuk mengelola setting dan perbaikan mesin produksi.

## Fitur
- Dashboard overview 10 mesin produksi
- CRUD Setting Mesin dengan upload foto panduan
- Tracking Perbaikan Mesin dengan status & teknisi
- Responsive design (desktop, tablet, mobile)

## Struktur Folder

production-dashboard/
├── backend/          # API Server (Node.js + Express + SQLite)
│   ├── server.js
│   ├── database.js
│   ├── package.json
│   └── uploads/      # Folder penyimpanan foto
├── frontend/         # React App (React + TypeScript + Tailwind)
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── context/
│   │   └── App.tsx
│   ├── package.json
│   └── index.html
└── preview.html      # Versi standalone (tanpa backend)

## Cara Menjalankan (Full Stack)

### 1. Backend
```bash
cd backend
npm install
mkdir uploads
npm run dev
```
Server berjalan di http://localhost:3001

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```
Aplikasi berjalan di http://localhost:5173

## Cara Menjalankan (Preview Only)
Buka file `preview.html` langsung di browser tanpa perlu install apapun.

## Mesin yang Tersedia
1. Mesin Filling
2. Mesin Crimping
3. Mesin Collar
4. Mesin Label
5. Mesin Coding Hitachi
6. Mesin Cartoning
7. Mesin Check Weigher
8. Mesin Blister Auto
9. Mesin Blister Manual
10. Mesin Carton Sealer

## Teknologi
- Backend: Node.js, Express, SQLite, Multer
- Frontend: React 18, TypeScript, Tailwind CSS, React Router
- Icons: Lucide React / Font Awesome
