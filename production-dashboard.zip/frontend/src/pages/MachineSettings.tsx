import { useParams, useNavigate } from 'react-router-dom';
import { useMachines } from '../context/MachineContext';
import { useEffect } from 'react';
import { ArrowLeft, Plus, Pencil, Trash2 } from 'lucide-react';

const API_URL = 'http://localhost:3001';

export default function MachineSettings() {
  const { machineId } = useParams<{ machineId: string }>();
  const navigate = useNavigate();
  const { machines, settings, fetchSettings, deleteSetting } = useMachines();

  const machine = machines.find(m => m.id === machineId);
  const machineSettings = settings[machineId || ''] || [];

  useEffect(() => {
    if (machineId) fetchSettings(machineId);
  }, [machineId]);

  const handleDelete = async (settingId: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus langkah ini?')) return;
    if (machineId) await deleteSetting(settingId, machineId);
  };

  if (!machine) return <div>Mesin tidak ditemukan</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{machine.name}</h2>
            <p className="text-gray-500">Setting & Konfigurasi Mesin</p>
          </div>
        </div>
        <button onClick={() => navigate(`/settings/${machineId}/new`)} className="btn-primary">
          <Plus className="w-5 h-5" /> Tambah Langkah
        </button>
      </div>

      <div className="space-y-4">
        {machineSettings.length === 0 ? (
          <div className="card text-center py-12">
            <Settings className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Belum ada langkah setting</h3>
            <p className="text-gray-500 mt-1">Tambahkan langkah-langkah konfigurasi mesin</p>
            <button onClick={() => navigate(`/settings/${machineId}/new`)} className="btn-primary mt-4 mx-auto">
              <Plus className="w-5 h-5" /> Tambah Langkah Pertama
            </button>
          </div>
        ) : (
          machineSettings.map((setting) => (
            <div key={setting.id} className="card step-card">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center font-bold">
                    {setting.step_order}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{setting.title}</h4>
                      {setting.description && <p className="text-gray-600 mt-1 text-sm">{setting.description}</p>}
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => navigate(`/settings/${machineId}/edit/${setting.id}`)} className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors" title="Edit">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(setting.id)} className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors" title="Hapus">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  {setting.image_path && (
                    <div className="mt-4">
                      <div className="relative rounded-xl overflow-hidden bg-gray-100 border border-gray-200 max-w-md">
                        <img src={`${API_URL}${setting.image_path}`} alt={setting.title} className="w-full h-48 object-cover" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}