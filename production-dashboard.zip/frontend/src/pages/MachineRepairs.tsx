import { useParams, useNavigate } from 'react-router-dom';
import { useMachines } from '../context/MachineContext';
import { useState, useEffect } from 'react';
import { ArrowLeft, Plus, CheckCircle2, Clock, User, Wrench } from 'lucide-react';

export default function MachineRepairs() {
  const { machineId } = useParams<{ machineId: string }>();
  const navigate = useNavigate();
  const { machines, repairs, fetchRepairs, addRepair, completeRepair } = useMachines();

  const [showForm, setShowForm] = useState(false);
  const [issue, setIssue] = useState('');
  const [solution, setSolution] = useState('');
  const [technician, setTechnician] = useState('');

  const machine = machines.find(m => m.id === machineId);
  const machineRepairs = repairs[machineId || ''] || [];

  useEffect(() => {
    if (machineId) fetchRepairs(machineId);
  }, [machineId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!machineId) return;
    await addRepair({ machine_id: machineId, issue, solution: solution || null, technician: technician || null });
    setIssue(''); setSolution(''); setTechnician(''); setShowForm(false);
  };

  const handleComplete = async (repairId: string) => {
    if (!machineId) return;
    await completeRepair(repairId, machineId);
  };

  if (!machine) return <div>Mesin tidak ditemukan</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{machine.name}</h2>
            <p className="text-gray-500">Riwayat Perbaikan & Maintenance</p>
          </div>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary">
          <Plus className="w-5 h-5" /> Catat Perbaikan
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card space-y-4 animate-fade-in">
          <h3 className="font-semibold text-gray-900">Catat Perbaikan Baru</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Masalah / Kerusakan <span className="text-red-500">*</span></label>
            <textarea value={issue} onChange={(e) => setIssue(e.target.value)} placeholder="Deskripsikan masalah yang terjadi..." rows={3} className="input-field resize-none" required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Solusi / Tindakan</label>
              <input type="text" value={solution} onChange={(e) => setSolution(e.target.value)} placeholder="Bagaimana masalah diselesaikan..." className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Nama Teknisi</label>
              <input type="text" value={technician} onChange={(e) => setTechnician(e.target.value)} placeholder="Nama teknisi yang menangani" className="input-field" />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Batal</button>
            <button type="submit" className="btn-primary"><CheckCircle2 className="w-4 h-4" /> Simpan</button>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {machineRepairs.length === 0 ? (
          <div className="card text-center py-12">
            <Wrench className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Belum ada riwayat perbaikan</h3>
            <p className="text-gray-500 mt-1">Catat perbaikan pertama untuk mesin ini</p>
          </div>
        ) : (
          machineRepairs.map((repair) => (
            <div key={repair.id} className={`card border-l-4 ${repair.status === 'completed' ? 'border-l-green-500' : 'border-l-yellow-500'}`}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${repair.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {repair.status === 'completed' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                      {repair.status === 'completed' ? 'Selesai' : 'Dalam Proses'}
                    </span>
                    <span className="text-xs text-gray-400">{new Date(repair.created_at).toLocaleDateString('id-ID')}</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">{repair.issue}</h4>
                  {repair.solution && <p className="text-sm text-gray-600 mb-2"><span className="font-medium">Solusi:</span> {repair.solution}</p>}
                  {repair.technician && <div className="flex items-center gap-1 text-sm text-gray-500"><User className="w-3 h-3" /> {repair.technician}</div>}
                </div>
                {repair.status === 'pending' && (
                  <button onClick={() => handleComplete(repair.id)} className="btn-primary text-sm"><CheckCircle2 className="w-4 h-4" /> Selesai</button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}