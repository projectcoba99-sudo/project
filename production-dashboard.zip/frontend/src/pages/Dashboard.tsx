import { useNavigate } from 'react-router-dom';
import { useMachines } from '../context/MachineContext';
import { Settings, Wrench, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useEffect } from 'react';

const machineIcons: Record<string, string> = {
  filling: '🥤', crimping: '🔧', collar: '🏷️', label: '🏷️',
  coding: '🖨️', cartoning: '📦', check_weigher: '⚖️',
  blister_auto: '💊', blister_manual: '💊', carton_sealer: '📦'
};

export default function Dashboard() {
  const { machines, loading, fetchMachines } = useMachines();
  const navigate = useNavigate();

  useEffect(() => { fetchMachines(); }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-red-100 text-red-700 border-red-200';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard Mesin Produksi</h2>
        <p className="text-gray-500 mt-1">Kelola setting dan perbaikan seluruh mesin produksi</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card bg-blue-50 border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-600">Total Mesin</p>
              <p className="text-3xl font-bold text-blue-900 mt-1">{machines.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="card bg-green-50 border-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600">Mesin Aktif</p>
              <p className="text-3xl font-bold text-green-900 mt-1">{machines.filter(m => m.status === 'active').length}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
        <div className="card bg-yellow-50 border-yellow-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-600">Perlu Perawatan</p>
              <p className="text-3xl font-bold text-yellow-900 mt-1">{machines.filter(m => m.status === 'maintenance').length}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Daftar Mesin</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {machines.map((machine) => {
            const statusColors = {
              active: 'bg-green-100 text-green-700 border-green-200',
              maintenance: 'bg-yellow-100 text-yellow-700 border-yellow-200',
              offline: 'bg-red-100 text-red-700 border-red-200'
            };
            const statusLabels = { active: 'Aktif', maintenance: 'Perawatan', offline: 'Offline' };

            return (
              <div key={machine.id} className="card card-hover">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-2xl">
                      {machineIcons[machine.type] || '⚙️'}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{machine.name}</h4>
                      <p className="text-sm text-gray-500">{machine.location}</p>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${statusColors[machine.status]}`}>
                    {machine.status === 'active' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {statusLabels[machine.status]}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => navigate(`/settings/${machine.id}`)} className="btn-secondary justify-center text-sm">
                    <Settings className="w-4 h-4" /> Setting
                  </button>
                  <button onClick={() => navigate(`/repairs/${machine.id}`)} className="btn-secondary justify-center text-sm">
                    <Wrench className="w-4 h-4" /> Perbaikan
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}