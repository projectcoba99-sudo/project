import { useParams, useNavigate } from 'react-router-dom';
import { useMachines } from '../context/MachineContext';
import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Upload, X } from 'lucide-react';

export default function SettingForm() {
  const { machineId, settingId } = useParams<{ machineId: string; settingId?: string }>();
  const navigate = useNavigate();
  const { machines, settings, fetchSettings, addSetting, updateSetting } = useMachines();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [stepOrder, setStepOrder] = useState(1);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [existingImage, setExistingImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isEditing = !!settingId;

  const machine = machines.find(m => m.id === machineId);
  const machineSettings = settings[machineId || ''] || [];
  const existingSetting = machineSettings.find(s => s.id === settingId);

  useEffect(() => {
    if (isEditing && existingSetting) {
      setTitle(existingSetting.title);
      setDescription(existingSetting.description || '');
      setStepOrder(existingSetting.step_order);
      if (existingSetting.image_path) {
        setExistingImage(`http://localhost:3001${existingSetting.image_path}`);
      }
    } else {
      const maxOrder = machineSettings.reduce((max, s) => Math.max(max, s.step_order), 0);
      setStepOrder(maxOrder + 1);
    }
  }, [isEditing, existingSetting, machineSettings]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!machineId) return;
    setSaving(true);
    try {
      const formData = new FormData();
      formData.append('machine_id', machineId);
      formData.append('title', title);
      formData.append('description', description);
      formData.append('step_order', stepOrder.toString());
      if (selectedFile) formData.append('image', selectedFile);

      if (isEditing && settingId) {
        await updateSetting(settingId, formData);
      } else {
        await addSetting(machineId, formData);
      }
      navigate(`/settings/${machineId}`);
    } catch (error) {
      alert('Gagal menyimpan. Silakan coba lagi.');
    } finally {
      setSaving(false);
    }
  };

  if (!machine) return <div>Mesin tidak ditemukan</div>;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(`/settings/${machineId}`)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{isEditing ? 'Edit Langkah' : 'Tambah Langkah Baru'}</h2>
          <p className="text-gray-500">{machine.name}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="card space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Nomor Urut Langkah</label>
          <input type="number" min={1} value={stepOrder} onChange={(e) => setStepOrder(parseInt(e.target.value))} className="input-field w-32" required />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Judul Langkah <span className="text-red-500">*</span></label>
          <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Contoh: Persiapan Bahan Baku" className="input-field" required />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Deskripsi / Penjelasan</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Jelaskan langkah-langkah detail..." rows={4} className="input-field resize-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Foto / Gambar Panduan</label>
          {(imagePreview || existingImage) ? (
            <div className="relative rounded-xl overflow-hidden border border-gray-200 max-w-md">
              <img src={imagePreview || existingImage || ''} alt="Preview" className="w-full h-48 object-cover" />
              <button type="button" onClick={() => { setImagePreview(null); setExistingImage(null); setSelectedFile(null); }} className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all max-w-md">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-sm font-medium text-gray-700">Klik untuk upload gambar</p>
              <p className="text-xs text-gray-500 mt-1">PNG, JPG, WEBP (Max 5MB)</p>
            </div>
          )}
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
        </div>
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
          <button type="button" onClick={() => navigate(`/settings/${machineId}`)} className="btn-secondary">Batal</button>
          <button type="submit" disabled={saving} className="btn-primary disabled:opacity-50">
            {saving ? 'Menyimpan...' : <><Upload className="w-4 h-4" /> {isEditing ? 'Simpan Perubahan' : 'Tambah Langkah'}</>}
          </button>
        </div>
      </form>
    </div>
  );
}