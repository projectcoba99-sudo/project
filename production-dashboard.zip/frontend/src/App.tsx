import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import MachineSettings from './pages/MachineSettings';
import MachineRepairs from './pages/MachineRepairs';
import SettingForm from './pages/SettingForm';
import { MachineProvider } from './context/MachineContext';

function App() {
  return (
    <MachineProvider>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="settings/:machineId" element={<MachineSettings />} />
          <Route path="settings/:machineId/new" element={<SettingForm />} />
          <Route path="settings/:machineId/edit/:settingId" element={<SettingForm />} />
          <Route path="repairs/:machineId" element={<MachineRepairs />} />
        </Route>
      </Routes>
    </MachineProvider>
  );
}

export default App;