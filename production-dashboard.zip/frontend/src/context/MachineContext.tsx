import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

export interface Machine {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'maintenance' | 'offline';
  location: string;
}

export interface Setting {
  id: string;
  machine_id: string;
  title: string;
  description: string | null;
  step_order: number;
  image_path: string | null;
  created_at: string;
  updated_at: string;
}

export interface Repair {
  id: string;
  machine_id: string;
  issue: string;
  solution: string | null;
  technician: string | null;
  status: 'pending' | 'completed';
  created_at: string;
  completed_at: string | null;
}

interface MachineContextType {
  machines: Machine[];
  settings: Record<string, Setting[]>;
  repairs: Record<string, Repair[]>;
  loading: boolean;
  fetchMachines: () => Promise<void>;
  fetchSettings: (machineId: string) => Promise<void>;
  fetchRepairs: (machineId: string) => Promise<void>;
  addSetting: (machineId: string, formData: FormData) => Promise<void>;
  updateSetting: (settingId: string, formData: FormData) => Promise<void>;
  deleteSetting: (settingId: string, machineId: string) => Promise<void>;
  addRepair: (repair: Omit<Repair, 'id' | 'created_at' | 'completed_at' | 'status'>) => Promise<void>;
  completeRepair: (repairId: string, machineId: string) => Promise<void>;
}

const MachineContext = createContext<MachineContextType | undefined>(undefined);

export function MachineProvider({ children }: { children: ReactNode }) {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [settings, setSettings] = useState<Record<string, Setting[]>>({});
  const [repairs, setRepairs] = useState<Record<string, Repair[]>>({});
  const [loading, setLoading] = useState(false);

  const fetchMachines = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API_URL}/machines`);
      setMachines(data.data);
    } catch (error) {
      console.error('Error fetching machines:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSettings = async (machineId: string) => {
    try {
      const { data } = await axios.get(`${API_URL}/machines/${machineId}/settings`);
      setSettings(prev => ({ ...prev, [machineId]: data.data }));
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const fetchRepairs = async (machineId: string) => {
    try {
      const { data } = await axios.get(`${API_URL}/machines/${machineId}/repairs`);
      setRepairs(prev => ({ ...prev, [machineId]: data.data }));
    } catch (error) {
      console.error('Error fetching repairs:', error);
    }
  };

  const addSetting = async (machineId: string, formData: FormData) => {
    await axios.post(`${API_URL}/settings`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    await fetchSettings(machineId);
  };

  const updateSetting = async (settingId: string, formData: FormData) => {
    const machineId = formData.get('machine_id') as string;
    await axios.put(`${API_URL}/settings/${settingId}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    await fetchSettings(machineId);
  };

  const deleteSetting = async (settingId: string, machineId: string) => {
    await axios.delete(`${API_URL}/settings/${settingId}`);
    await fetchSettings(machineId);
  };

  const addRepair = async (repair: Omit<Repair, 'id' | 'created_at' | 'completed_at' | 'status'>) => {
    await axios.post(`${API_URL}/repairs`, repair);
    await fetchRepairs(repair.machine_id);
  };

  const completeRepair = async (repairId: string, machineId: string) => {
    await axios.patch(`${API_URL}/repairs/${repairId}/complete`);
    await fetchRepairs(machineId);
  };

  useEffect(() => {
    fetchMachines();
  }, []);

  return (
    <MachineContext.Provider value={{
      machines, settings, repairs, loading,
      fetchMachines, fetchSettings, fetchRepairs,
      addSetting, updateSetting, deleteSetting,
      addRepair, completeRepair
    }}>
      {children}
    </MachineContext.Provider>
  );
}

export const useMachines = () => {
  const context = useContext(MachineContext);
  if (!context) throw new Error('useMachines must be used within MachineProvider');
  return context;
};