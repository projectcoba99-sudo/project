import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './database.js';
import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: (req, file, cb) => { cb(null, 'uploads/'); },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) return cb(null, true);
    cb(new Error('Hanya file gambar yang diizinkan!'));
  }
});

const SettingSchema = z.object({
  machine_id: z.string().uuid(),
  title: z.string().min(1, 'Judul wajib diisi'),
  description: z.string().optional(),
  step_order: z.number().int().min(1)
});

const RepairSchema = z.object({
  machine_id: z.string().uuid(),
  issue: z.string().min(1, 'Masalah wajib diisi'),
  solution: z.string().optional(),
  technician: z.string().optional()
});

app.get('/api/machines', (req, res) => {
  try {
    const machines = db.prepare('SELECT * FROM machines ORDER BY created_at').all();
    res.json({ success: true, data: machines });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/machines/:id', (req, res) => {
  try {
    const machine = db.prepare('SELECT * FROM machines WHERE id = ?').get(req.params.id);
    if (!machine) return res.status(404).json({ success: false, error: 'Mesin tidak ditemukan' });
    res.json({ success: true, data: machine });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/machines/:id/settings', (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM settings WHERE machine_id = ? ORDER BY step_order').all(req.params.id);
    res.json({ success: true, data: settings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/settings', upload.single('image'), (req, res) => {
  try {
    const data = SettingSchema.parse({ ...req.body, step_order: parseInt(req.body.step_order) });
    const id = uuidv4();
    const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

    db.prepare(`INSERT INTO settings (id, machine_id, title, description, step_order, image_path) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(id, data.machine_id, data.title, data.description || null, data.step_order, imagePath);

    const setting = db.prepare('SELECT * FROM settings WHERE id = ?').get(id);
    res.status(201).json({ success: true, data: setting });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.put('/api/settings/:id', upload.single('image'), (req, res) => {
  try {
    const existing = db.prepare('SELECT * FROM settings WHERE id = ?').get(req.params.id);
    if (!existing) return res.status(404).json({ success: false, error: 'Setting tidak ditemukan' });

    const data = SettingSchema.partial().parse({ ...req.body, step_order: req.body.step_order ? parseInt(req.body.step_order) : undefined });
    const imagePath = req.file ? `/uploads/${req.file.filename}` : existing.image_path;

    db.prepare(`UPDATE settings SET title = COALESCE(?, title), description = COALESCE(?, description), step_order = COALESCE(?, step_order), image_path = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .run(data.title || null, data.description || null, data.step_order || null, imagePath, req.params.id);

    const updated = db.prepare('SELECT * FROM settings WHERE id = ?').get(req.params.id);
    res.json({ success: true, data: updated });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/settings/:id', (req, res) => {
  try {
    const result = db.prepare('DELETE FROM settings WHERE id = ?').run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ success: false, error: 'Setting tidak ditemukan' });
    res.json({ success: true, message: 'Setting berhasil dihapus' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/machines/:id/repairs', (req, res) => {
  try {
    const repairs = db.prepare('SELECT * FROM repairs WHERE machine_id = ? ORDER BY created_at DESC').all(req.params.id);
    res.json({ success: true, data: repairs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/repairs', (req, res) => {
  try {
    const data = RepairSchema.parse(req.body);
    const id = uuidv4();
    db.prepare(`INSERT INTO repairs (id, machine_id, issue, solution, technician) VALUES (?, ?, ?, ?, ?)`)
      .run(id, data.machine_id, data.issue, data.solution || null, data.technician || null);
    const repair = db.prepare('SELECT * FROM repairs WHERE id = ?').get(id);
    res.status(201).json({ success: true, data: repair });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.patch('/api/repairs/:id/complete', (req, res) => {
  try {
    db.prepare(`UPDATE repairs SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE id = ?`).run(req.params.id);
    const repair = db.prepare('SELECT * FROM repairs WHERE id = ?').get(req.params.id);
    res.json({ success: true, data: repair });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, error: err.message });
});

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});