import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';

const db = new Database('production.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS machines (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    location TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    id TEXT PRIMARY KEY,
    machine_id TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    step_order INTEGER NOT NULL,
    image_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (machine_id) REFERENCES machines(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS repairs (
    id TEXT PRIMARY KEY,
    machine_id TEXT NOT NULL,
    issue TEXT NOT NULL,
    solution TEXT,
    technician TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (machine_id) REFERENCES machines(id) ON DELETE CASCADE
  );
`);

const machineCount = db.prepare('SELECT COUNT(*) as count FROM machines').get();
if (machineCount.count === 0) {
  const machines = [
    { id: uuidv4(), name: 'Mesin Filling', type: 'filling', location: 'Line 1' },
    { id: uuidv4(), name: 'Mesin Crimping', type: 'crimping', location: 'Line 1' },
    { id: uuidv4(), name: 'Mesin Collar', type: 'collar', location: 'Line 2' },
    { id: uuidv4(), name: 'Mesin Label', type: 'label', location: 'Line 2' },
    { id: uuidv4(), name: 'Mesin Coding Hitachi', type: 'coding', location: 'Line 3' },
    { id: uuidv4(), name: 'Mesin Cartoning', type: 'cartoning', location: 'Line 3' },
    { id: uuidv4(), name: 'Mesin Check Weigher', type: 'check_weigher', location: 'Line 4' },
    { id: uuidv4(), name: 'Mesin Blister Auto', type: 'blister_auto', location: 'Line 4' },
    { id: uuidv4(), name: 'Mesin Blister Manual', type: 'blister_manual', location: 'Line 5' },
    { id: uuidv4(), name: 'Mesin Carton Sealer', type: 'carton_sealer', location: 'Line 5' }
  ];

  const insertMachine = db.prepare('INSERT INTO machines (id, name, type, location) VALUES (?, ?, ?, ?)');
  machines.forEach(m => insertMachine.run(m.id, m.name, m.type, m.location));
}

export default db;